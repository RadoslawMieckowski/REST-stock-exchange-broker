package com.griddynamics.fancyproject.model;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.LinkedList;
import java.util.List;

@Entity
@Table(name = "USERS")
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(exclude = "orders")
@ToString(exclude = "orders")
@Builder
@AllArgsConstructor
public class User {

    public enum UserType {
        REGULAR,
        PRO
    }

    @Id
    @Column(
            name = "USER_ID",
            updatable = false
    )
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(
            name = "USER_NAME",
            nullable = false
    )
    private String name;

    @Column(
            name = "USER_TYPE",
            nullable = false
    )
    @Enumerated(EnumType.STRING)
    private UserType type;

    @Column(
            name = "JOIN_DATE",
            nullable = false
    )
    private OffsetDateTime joinDate;


    @Column(
            name = "EMAIL",
            nullable = false
    )
    private String email;



    @Column(
            name = "PASSWORD",
            nullable = false
    )
    private String password;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "user")
    private List<Order> orders = new LinkedList<>();

}
