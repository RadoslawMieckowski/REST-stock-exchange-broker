package com.griddynamics.fancyproject.model;

import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "ORDERS")
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class Order {

    public enum OrderType {
        BUY,
        SELL
    }

    @Id
    @Column(
            name = "ORDER_ID",
            updatable = false
    )
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(
            name = "STOCK_ID",
            nullable = false
    )
    private Stock stock;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(
            name = "USER_ID",
            nullable = false
    )
    private User user;

    @Column(
            name = "ORDER_QUANTITY",
            nullable = false
    )
    private long quantity;

    @Column(
            name = "TOTAL_PRICE"
    )
    @Builder.Default
    private BigDecimal totalPrice = BigDecimal.ZERO;

    @Column(
            name = "ORDER_TYPE",
            nullable = false
    )
    @Enumerated(EnumType.STRING)
    private OrderType type;

    @Column(
            name = "DISCOUNT"
    )
    @Builder.Default
    private BigDecimal discount = BigDecimal.ZERO;

    @Column(
            name = "TAX"
    )
    @Builder.Default
    private BigDecimal tax = BigDecimal.ZERO;

    @Column(
            name = "BROKER_COMMISSION",
            nullable = false
    )
    @Builder.Default
    private BigDecimal brokerCommission = BigDecimal.ZERO;

    @Column(
            name = "ORDER_DATE",
            nullable = false
    )
    private OffsetDateTime orderDate;
}
