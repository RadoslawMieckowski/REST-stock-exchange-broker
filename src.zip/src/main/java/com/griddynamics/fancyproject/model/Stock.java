package com.griddynamics.fancyproject.model;

import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "STOCKS")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(exclude = "orders")
@ToString(exclude = "orders")
@Builder
public class Stock {

    @Id
    @Column(
            name = "STOCK_ID",
            updatable = false
    )
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(
            name = "STOCK_NAME",
            nullable = false
    )
    private String name;

    @Column(
            name = "STOCK_TICKER",
            nullable = false
    )
    private String ticker;

    @Column(
            name = "QUANTITY",
            nullable = false
    )
    private long quantity;

    @Column(
            name = "STOCK_PRICE",
            nullable = false
    )
    @Builder.Default
    private BigDecimal price = BigDecimal.ZERO;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "stock")
    private Set<Order> orders = new HashSet<>();
}