package com.griddynamics.fancyproject.service.calculator.impl;

import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.service.calculator.OrdersCalculator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class BrokerDiscountCalculator implements OrdersCalculator {

    private final Map<String, Double> discounts;
    private static final String DELIMITER = ":";
    private static final int PERCENTAGE_DIVIDER = 100;

    public BrokerDiscountCalculator(@Value("#{'${stock.exchange.service.broker.discount}'.split(',')}") List<String> discounts){
        this.discounts = discounts.stream()
                .collect(Collectors.toMap(elem -> elem.split(DELIMITER)[0], elem -> Double.parseDouble(elem.split(DELIMITER)[1])));
    }

    @Override
    public void calculate(List<Order> orders) {
        orders.stream()
                .filter(order -> order.getType() == Order.OrderType.BUY)
                .forEach(order -> order.setDiscount(BigDecimal.valueOf(this.discounts.getOrDefault(order.getStock().getTicker(), 0d) / PERCENTAGE_DIVIDER).multiply(order.getStock().getPrice().multiply(BigDecimal.valueOf(order.getQuantity())))));
    }
}
