package com.griddynamics.fancyproject.service.calculator.impl;

import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.service.calculator.OrdersCalculator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
public class TaxCalculator implements OrdersCalculator {

    private static final int PERCENTAGE_DIVIDER = 100;
    private final double tax;

    public TaxCalculator(@Value("${stock.exchange.service.broker.tax}") double tax){
        this.tax = tax / PERCENTAGE_DIVIDER;
    }

    @Override
    public void calculate(List<Order> orders) {
        orders.stream()
                .filter(order -> order.getType() == Order.OrderType.SELL)
                .forEach(order -> order.setTax(BigDecimal.valueOf(this.tax).multiply(order.getStock().getPrice().multiply(BigDecimal.valueOf(order.getQuantity())))));
    }
}
