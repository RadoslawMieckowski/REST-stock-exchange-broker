package com.griddynamics.fancyproject.service;

import com.griddynamics.fancyproject.controllers.mapper.UserInputMapper;
import com.griddynamics.fancyproject.model.User;
import com.griddynamics.fancyproject.model.dto.UserInputDto;
import com.griddynamics.fancyproject.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.regex.Pattern;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final UserInputMapper userInputMapper;

    @Autowired
    public UserService(
            UserRepository userRepository,
            UserInputMapper userInputMapper
    ) {
       this.userRepository = userRepository;
       this.userInputMapper = userInputMapper;
    }

    /*
    It allows numeric values from 0 to 9.
    Both uppercase and lowercase letters from a to z are allowed.
    Allowed are underscore “_”, hyphen “-“, and dot “.”
    Dot isn't allowed at the start and end of the local part.
    Consecutive dots aren't allowed.
    For the local part, a maximum of 64 characters are allowed.
    It allows numeric values from 0 to 9.
    We allow both uppercase and lowercase letters from a to z.
    Hyphen “-” and dot “.” aren't allowed at the start and end of the domain part.
    No consecutive dots.
     */
    private boolean validateEmail(String email) {
        String regexPattern = "^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@"
                + "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
        return Pattern.compile(regexPattern)
                .matcher(email)
                .matches();
    }

    private String encodePassword(String plain_password) {
        return BCrypt.hashpw(plain_password, BCrypt.gensalt(11));
    }

    public void addNewUserToDatabase(UserInputDto userInputDto) {
        boolean isEmailValid = validateEmail(userInputDto.getEmail());
        if (isEmailValid) {
            User user = userInputMapper.fromUserInput(userInputDto);
            user.setPassword(encodePassword(user.getPassword()));
            user.setJoinDate(OffsetDateTime.now());
            userRepository.save(user);
        }
    }
}
