package com.griddynamics.fancyproject.service.calculator;

import com.griddynamics.fancyproject.model.Order;

import java.util.List;

public interface OrdersCalculator {

    void calculate(List<Order> orders);

}
