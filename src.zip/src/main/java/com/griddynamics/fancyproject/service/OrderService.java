package com.griddynamics.fancyproject.service;

import com.griddynamics.fancyproject.exceptions.NotEnoughStockException;
import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.repository.OrderRepository;
import com.griddynamics.fancyproject.repository.StockRepository;
import com.griddynamics.fancyproject.repository.UserRepository;
import com.griddynamics.fancyproject.service.calculator.OrdersCalculator;
import com.griddynamics.fancyproject.service.calculator.impl.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final StockRepository stockRepository;
    private final UserRepository userRepository;

    private final List<OrdersCalculator> calculators;

    @Autowired
    public OrderService(
            OrderRepository orderRepository,
            StockRepository stockRepository,
            UserRepository userRepository,
            ApplicationContext applicationContext
    ) {
        this.orderRepository = orderRepository;
        this.stockRepository = stockRepository;
        this.userRepository = userRepository;
        calculators = new LinkedList<>(List.of(
                applicationContext.getBean(BrokerCommissionCalculator.class),
                applicationContext.getBean(BrokerDiscountCalculator.class),
                applicationContext.getBean(TaxCalculator.class),
                applicationContext.getBean(FreeStockCalculator.class),
                applicationContext.getBean(FinalOrderValueCalculator.class)
        ));
    }

    @Transactional
    public void makeOrder(List<Order> orders) {
        orders.forEach(this::validateOrder);
        calculators.forEach(calculator -> calculator.calculate(orders));
        orders.forEach(order -> {
            var databaseStock = stockRepository.findByTicker(order.getStock().getTicker()).get();
            if (order.getType() == Order.OrderType.SELL) {
                databaseStock.setQuantity(databaseStock.getQuantity() - order.getQuantity());
            } else {
                databaseStock.setQuantity(databaseStock.getQuantity() + order.getQuantity());
            }
            orderRepository.save(order);
            var databaseUser = userRepository.findById(order.getUser().getId()).get();
            databaseUser.getOrders().add(order);
            databaseStock.getOrders().add(order);
        });
    }

    public List<Order> getOrders(OffsetDateTime begin, OffsetDateTime end, Long userId) {
        OffsetDateTime now = OffsetDateTime.now();
        if (begin == null) {
            begin = now.minusDays(1);
        }

        if (end == null) {
            end = now;
        }

        if (userId != null) {
            return new ArrayList<>(orderRepository.findByTimePeriodAndUser(begin, end, userId));
        } else {
            return new ArrayList<>(orderRepository.findByTimePeriod(begin, end));
        }
    }

    private void validateOrder(Order order) throws NotEnoughStockException {
        var brokerStockQuantity = stockRepository.findByTicker(order.getStock().getTicker()).get().getQuantity();
        var orderStockQuantity = order.getQuantity();
        if (order.getType() == Order.OrderType.BUY && orderStockQuantity > brokerStockQuantity) {
            throw new NotEnoughStockException("Order for more stock than possible.");
        }
    }
}
