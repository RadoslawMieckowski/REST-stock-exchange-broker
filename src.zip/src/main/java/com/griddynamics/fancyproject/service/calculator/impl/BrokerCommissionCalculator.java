package com.griddynamics.fancyproject.service.calculator.impl;

import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.model.User;
import com.griddynamics.fancyproject.service.calculator.OrdersCalculator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
public class BrokerCommissionCalculator implements OrdersCalculator {
    private final BigDecimal commissionBuy;
    private final BigDecimal commissionSell;
    private static final int PERCENTAGE_DIVIDER = 100;
    private static final double PRO_USER_COMMISION_DISCOUNT = 0.5;

    public BrokerCommissionCalculator(
            @Value("${stock.exchange.service.broker.commission.buy}") BigDecimal commissionBuy,
            @Value("${stock.exchange.service.broker.commission.sell}") BigDecimal commissionSell
    ) {
        this.commissionBuy = commissionBuy.divide(BigDecimal.valueOf(PERCENTAGE_DIVIDER));
        this.commissionSell = commissionSell.divide(BigDecimal.valueOf(PERCENTAGE_DIVIDER));
    }

    @Override
    public void calculate(List<Order> orders) {
        orders.stream().filter(
                        order -> order.getType() == Order.OrderType.BUY)
                .forEach(order -> order.setBrokerCommission(
                                BigDecimal.valueOf(order.getQuantity() *
                                        order.getStock().getPrice().doubleValue() *
                                        commissionBuy.doubleValue())
                        )
                );
        orders.stream().filter(
                        order -> order.getType() == Order.OrderType.SELL)
                .forEach(order -> order.setBrokerCommission(
                                BigDecimal.valueOf(order.getQuantity() *
                                        order.getStock().getPrice().doubleValue() *
                                        commissionSell.doubleValue())
                        )
                );
        orders.stream().filter(
                        order -> order.getUser().getType() == User.UserType.PRO)
                .forEach(order -> order.setBrokerCommission(
                        order.getBrokerCommission().multiply(
                                BigDecimal.valueOf(PRO_USER_COMMISION_DISCOUNT)
                        ))
                );
    }
}
