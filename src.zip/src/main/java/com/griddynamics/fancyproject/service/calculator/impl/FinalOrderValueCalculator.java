package com.griddynamics.fancyproject.service.calculator.impl;

import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.service.calculator.OrdersCalculator;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
public class FinalOrderValueCalculator implements OrdersCalculator {
    @Override
    public void calculate(List<Order> orders) {
        orders.stream().forEach(
                order -> order.setTotalPrice(
                        order.getStock().getPrice().multiply(BigDecimal.valueOf(order.getQuantity()))
                                .add(order.getTax())
                                .add(order.getBrokerCommission())
                                .subtract(order.getDiscount())
                )
        );
    }
}
