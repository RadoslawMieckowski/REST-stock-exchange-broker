package com.griddynamics.fancyproject.service.calculator.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:broker.properties")
public class CalculatorConfiguration {

}
