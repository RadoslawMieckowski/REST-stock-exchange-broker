package com.griddynamics.fancyproject.service.calculator.impl;

import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.service.calculator.OrdersCalculator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

@Component
public class FreeStockCalculator implements OrdersCalculator {

    private final BigDecimal minTransactionCost;

    public FreeStockCalculator(@Value("${stock.exchange.service.broker.free.stock.min}") BigDecimal minTransactionCost){
        this.minTransactionCost = minTransactionCost;
    }

    @Override
    public void calculate(List<Order> orders) {
        BigDecimal transactionCost = orders.stream()
                .map(order -> order.getStock().getPrice().multiply(BigDecimal.valueOf(order.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        if (transactionCost.compareTo(minTransactionCost) >= 0) {
            BigDecimal cheapestValue = orders.stream()
                    .map(order -> order.getStock().getPrice())
                    .min(BigDecimal::compareTo)
                    .get();

            orders.stream()
                    .filter(order -> Objects.equals(order.getStock().getPrice(), cheapestValue))
                    .findFirst()
                    .ifPresent(order -> order.setDiscount(order.getDiscount().add(cheapestValue)));
        }
    }
}

