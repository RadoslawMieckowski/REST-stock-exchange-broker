package com.griddynamics.fancyproject.service;

import com.griddynamics.fancyproject.exceptions.NoSuchTickerException;
import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.repository.StockRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class StockService {

    private final StockRepository stockRepository;

    public List<Stock> getAllStocks() {
        return stockRepository.findAll().stream().toList();
    }

    public Stock getStockByTicker(String ticker) {
        var stock = stockRepository.findByTicker(ticker);

        if (stock.isEmpty()) {
            throw new NoSuchTickerException("Stock with ticker " + ticker + " doesn't exist.");
        }
        return stock.get();
    }
}
