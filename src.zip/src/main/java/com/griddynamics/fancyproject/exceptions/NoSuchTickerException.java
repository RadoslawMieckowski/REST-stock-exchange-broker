package com.griddynamics.fancyproject.exceptions;

public class NoSuchTickerException extends RuntimeException {
    public NoSuchTickerException(String msg) {
        super(msg);
    }
}
