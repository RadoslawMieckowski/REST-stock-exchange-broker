package com.griddynamics.fancyproject.exceptions;

public class NoSuchStockException extends RuntimeException {
    public NoSuchStockException(String msg) {
        super(msg);
    }


}
