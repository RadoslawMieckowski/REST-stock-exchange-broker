package com.griddynamics.fancyproject.exceptions;

import java.util.List;

public class WrongDtoException extends RuntimeException {

    public WrongDtoException(String msg, List<String> errors) {
        super(msg + ((errors == null)
                ? ""
                : String.join(", ", errors))
        );
    }
}
