package com.griddynamics.fancyproject.exceptions;

public class NoSuchUserException extends RuntimeException{
    public NoSuchUserException(String msg){
        super(msg);
    }


}
