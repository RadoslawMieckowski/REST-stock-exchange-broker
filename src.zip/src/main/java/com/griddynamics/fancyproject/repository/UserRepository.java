package com.griddynamics.fancyproject.repository;

import com.griddynamics.fancyproject.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
}
