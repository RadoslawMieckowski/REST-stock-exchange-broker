package com.griddynamics.fancyproject.repository;

import com.griddynamics.fancyproject.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.OffsetDateTime;
import java.util.Collection;

public interface OrderRepository extends JpaRepository<Order, Long> {
    @Query(
            value = "SELECT * FROM ORDERS o WHERE o.ORDER_DATE > ?1 AND o.ORDER_DATE < ?2 AND o.USER_ID = ?3",
            nativeQuery = true
    )
    Collection<Order> findByTimePeriodAndUser(OffsetDateTime begin, OffsetDateTime end, Long userId);

    @Query(
            value = "SELECT * FROM ORDERS o WHERE o.ORDER_DATE > ?1 AND o.ORDER_DATE < ?2",
            nativeQuery = true
    )
    Collection<Order> findByTimePeriod(OffsetDateTime begin, OffsetDateTime end);
}
