package com.griddynamics.fancyproject.controllers.mapper;

import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.model.dto.StockInputDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface StockInputMapper {

    Stock fromInputDto(StockInputDto stockInputDto);

    StockInputDto toInputDto(Stock stock);
}
