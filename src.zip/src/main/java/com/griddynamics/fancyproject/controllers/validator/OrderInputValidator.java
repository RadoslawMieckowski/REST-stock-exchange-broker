package com.griddynamics.fancyproject.controllers.validator;

import com.griddynamics.fancyproject.exceptions.WrongDtoException;
import com.griddynamics.fancyproject.model.dto.OrderInputDto;
import lombok.experimental.UtilityClass;

import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

@UtilityClass
public class OrderInputValidator {

    private final Pattern tickerPattern = Pattern.compile("^[A-Z]{1,4}$");

    public List<String> validate(OrderInputDto orderInputDto) {

        List<String> errors = new LinkedList<>();

        if (orderInputDto == null) {
            errors.add("Input is null");
            throw new WrongDtoException("", errors);
        }

        if (orderInputDto.getUserId() == null) {
            errors.add("User id is missing");
        }

        if (orderInputDto.getType() == null) {
            errors.add("Type of transaction is missing");
        }

        if (orderInputDto.getTicker() == null) {
            errors.add("Ticker is missing");
        } else if (!tickerPattern.matcher(orderInputDto.getTicker()).matches()) {
            errors.add("Provided ticker is invalid");
        }

        if (orderInputDto.getQuantity() == null) {
            errors.add("Specified quantity is missing");
        } else if (orderInputDto.getQuantity() < 0) {
            errors.add("Provided quantity is invalid");
        }
        if (!errors.isEmpty()) {
            throw new WrongDtoException("One or more invalid input values: ", errors);
        }

        return errors;
    }
}
