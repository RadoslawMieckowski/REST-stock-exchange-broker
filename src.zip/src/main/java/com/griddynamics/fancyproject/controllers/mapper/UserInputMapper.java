package com.griddynamics.fancyproject.controllers.mapper;

import com.griddynamics.fancyproject.model.User;
import com.griddynamics.fancyproject.model.dto.UserInputDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public abstract class UserInputMapper {

    public abstract User fromUserInput(UserInputDto userInputDto);
}
