package com.griddynamics.fancyproject.controllers;

import com.griddynamics.fancyproject.api.StocksApi;
import com.griddynamics.fancyproject.controllers.mapper.StockMapper;
import com.griddynamics.fancyproject.model.dto.StockDto;
import com.griddynamics.fancyproject.service.StockService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class StocksController implements StocksApi {
    private List<StockDto> stocks = new ArrayList<>();

    private final StockService stockService;
    private final StockMapper stockMapper;

    @Override
    public ResponseEntity<List<StockDto>> getAllStocks() {
        var stockList = stockService.getAllStocks()
                .stream().map(stockMapper::toDto);
        return new ResponseEntity<>(stocks, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<StockDto> getStockByTicker(String ticker) {
        var stock = stockMapper.toDto(stockService.getStockByTicker(ticker));
        return new ResponseEntity<>(stock, HttpStatus.OK);
    }

    public List<StockDto> getStocksDto() {
        return stocks;
    }
}
