package com.griddynamics.fancyproject.controllers;

import com.griddynamics.fancyproject.api.UsersApi;
import com.griddynamics.fancyproject.model.dto.UserInputDto;
import com.griddynamics.fancyproject.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class UsersController implements UsersApi {
    private final UserService userService;

    @Override
    public ResponseEntity<Void> createUser(UserInputDto userInputDto) {
        userService.addNewUserToDatabase(userInputDto);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }
}
