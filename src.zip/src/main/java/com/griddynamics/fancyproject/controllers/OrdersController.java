package com.griddynamics.fancyproject.controllers;

import com.griddynamics.fancyproject.api.OrdersApi;
import com.griddynamics.fancyproject.controllers.mapper.OrderDtoMapper;
import com.griddynamics.fancyproject.controllers.mapper.OrderInputMapper;
import com.griddynamics.fancyproject.controllers.validator.OrderInputValidator;
import com.griddynamics.fancyproject.model.dto.OrderDto;
import com.griddynamics.fancyproject.model.dto.OrderInputDto;
import com.griddynamics.fancyproject.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class OrdersController implements OrdersApi {
    private List<OrderDto> orders = new ArrayList<>();

    private final OrderService orderService;
    private final OrderInputMapper orderInputMapper;
    private final OrderDtoMapper orderDtoMapper;

    @Override
    public ResponseEntity<List<OrderDto>> getOrders(
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime begin,
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) OffsetDateTime end,
            Long userId
    ) {
        var orderDtoS = orderService.getOrders(begin, end, userId).stream().map(orderDtoMapper::toDto).toList();
        return new ResponseEntity<>(orderDtoS, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> createOrder(List<OrderInputDto> listOrder) {
        var orders = listOrder.stream()
                .peek(OrderInputValidator::validate)
                .map(orderInputMapper::fromOrderInput)
                .toList();
        orderService.makeOrder(orders);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<OrderDto> getOrderById(String orderId) {
        long searchedId = Integer.parseInt(orderId);
        OrderDto order = orders.stream().filter(order1 -> order1.getId().longValue() == searchedId)
                .findFirst().get();
        return new ResponseEntity<>(order, HttpStatus.OK);
    }

    public List<OrderDto> getAllOrders() {
        return orders;
    }
}
