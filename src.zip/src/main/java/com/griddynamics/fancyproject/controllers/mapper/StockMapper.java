package com.griddynamics.fancyproject.controllers.mapper;

import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.model.dto.StockDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface StockMapper {

    StockDto toDto(Stock stock);

    Stock fromDto(StockDto stockDto);
}
