package com.griddynamics.fancyproject.controllers.mapper;

import com.griddynamics.fancyproject.exceptions.NoSuchStockException;
import com.griddynamics.fancyproject.exceptions.NoSuchUserException;
import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.model.User;
import com.griddynamics.fancyproject.model.dto.OrderInputDto;
import com.griddynamics.fancyproject.repository.StockRepository;
import com.griddynamics.fancyproject.repository.UserRepository;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.OffsetDateTime;

@Mapper(componentModel = "spring")
public abstract class OrderInputMapper {

    @Autowired
    protected StockRepository stockRepository;
    @Autowired
    protected UserRepository userRepository;

    @Mappings({
            @Mapping(target = "user", source = "orderInputDto.userId", qualifiedByName = "getUserById"),
            @Mapping(target = "stock", source = "orderInputDto.ticker", qualifiedByName = "getStockByTicker"),
            @Mapping(target = "orderDate", expression = "java(getCurrentTime())")
    })
    public abstract Order fromOrderInput(OrderInputDto orderInputDto);

    @Named("getUserById")
    protected User getUserById(long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new NoSuchUserException("User with id " + userId + " not found"));
    }

    @Named("getStockByTicker")
    protected Stock getStockByTicker(String ticker) {
        return stockRepository.findByTicker(ticker)
                .orElseThrow(() -> new NoSuchStockException("Stock with ticker " + ticker + " not found"));
    }

    protected OffsetDateTime getCurrentTime() {
        return OffsetDateTime.now();
    }

}
