package com.griddynamics.fancyproject.controllers.mapper;

import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.model.User;
import com.griddynamics.fancyproject.model.dto.OrderDto;
import com.griddynamics.fancyproject.model.dto.StockDto;
import com.griddynamics.fancyproject.model.dto.UserDto;
import org.mapstruct.*;

import java.time.OffsetDateTime;

@Mapper(componentModel = "spring")
public abstract class OrderDtoMapper {

    @Mappings({
            @Mapping(target = "user", source = "order.user", qualifiedByName = "getUserDto"),
            @Mapping(target = "stock", source = "order.stock", qualifiedByName = "getStockDto"),
            @Mapping(target = "date", expression = "java(convertDateTime(order.getOrderDate()))")
    })
    public abstract OrderDto toDto(Order order);

    @Named("getUserDto")
    protected UserDto getUserDto(User user) {
        var userType = user.getType() == User.UserType.PRO ? UserDto.TypeEnum.PRO : UserDto.TypeEnum.REGULAR;
        return UserDto.builder()
                .id(user.getId())
                .name(user.getName())
                .type(userType)
                .build();
    }

    @Named("getStockDto")
    protected StockDto getStockDto(Stock stock) {
        return StockDto.builder()
                .id(stock.getId())
                .ticker(stock.getTicker())
                .name(stock.getName())
                .quantity(stock.getQuantity())
                .price(stock.getPrice())
                .build();
    }

    protected String convertDateTime(OffsetDateTime offsetDateTime) {
        return offsetDateTime.toString();
    }
}
