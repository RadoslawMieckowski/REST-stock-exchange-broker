package com.griddynamics.fancyproject.controllers.mapper;

import com.griddynamics.fancyproject.model.User;
import com.griddynamics.fancyproject.model.dto.UserDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(componentModel = "spring")
public interface UserMapper {

    @Mappings(
            @Mapping(target = "type", source = "user.type")
    )
    UserDto toDto(User user);

    User fromDto(UserDto userDto);
}
