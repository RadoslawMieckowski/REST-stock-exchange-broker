package com.griddynamics.fancyproject.controllers.mapper;

import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.model.dto.OrderDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface OrderMapper {

    OrderDto toDto(Order order);

    Order fromDto(OrderDto orderDto);
}
