package com.griddynamics.fancyproject.service.calculator.impl;

import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.model.User;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.LinkedList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FreeStockCalculatorTest {
    static FreeStockCalculator calculator = new FreeStockCalculator(BigDecimal.valueOf(100));

    @Test
    void calculateShouldSet1CheapestStockAsDiscountWhenAboveMinTransactionCost() {

        Stock stock1 = new Stock();
        stock1.setId(1L);
        stock1.setName("AMAZON");
        stock1.setTicker("AMZ");
        stock1.setQuantity(100L);
        stock1.setPrice(BigDecimal.valueOf(20.0));

        Stock stock2 = new Stock();
        stock2.setId(3L);
        stock2.setName("TESLA");
        stock2.setTicker("TSLA");
        stock2.setQuantity(200L);
        stock2.setPrice(BigDecimal.valueOf(50.0));

        List<Order> orders = new LinkedList<>();
        User user = new User(4L, "Jan", User.UserType.REGULAR,
                OffsetDateTime.now(), "jan@wp.pl", "password", orders);

        Order order1 = Order.builder()
                .id(1L)
                .stock(stock1)
                .user(user)
                .quantity(2)
                .type(Order.OrderType.SELL)
                .discount(BigDecimal.valueOf(0))
                .build();
        Order order2 = Order.builder()
                .id(2L)
                .stock(stock2)
                .user(user)
                .quantity(2)
                .type(Order.OrderType.SELL)
                .discount(BigDecimal.valueOf(0))
                .build();

        orders.add(order1);
        orders.add(order2);

        calculator.calculate(orders);

        assertEquals(order1.getStock().getPrice(), order1.getDiscount());
        assertEquals(BigDecimal.ZERO, order2.getDiscount());

    }
}