package com.griddynamics.fancyproject.service.calculator.impl;

import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.model.User;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

class FinalOrderValueCalculatorTest {
    FinalOrderValueCalculator finalOrderValueCalculator = new FinalOrderValueCalculator();
    @Test
    void calculateTest() {
        List<Order> orders = new LinkedList<>();
        Stock stock = Stock.builder().id(1)
                .name("CD Projekt")
                .ticker("CDR")
                .price(BigDecimal.valueOf(50.0))
                .build();
        User user = User.builder()
                .id(1)
                .name("user1")
                .type(User.UserType.REGULAR)
                .build();
        Order order = Order.builder()
                .id(1)
                .stock(stock)
                .quantity(100)
                .user(user)
                .tax(BigDecimal.valueOf(15))
                .brokerCommission(BigDecimal.valueOf(5))
                .discount(BigDecimal.valueOf(3))
                .build();
        orders.add(order);

        finalOrderValueCalculator.calculate(orders);

        assertThat(order.getTotalPrice().doubleValue()).isEqualTo(5_017.00);
    }

}