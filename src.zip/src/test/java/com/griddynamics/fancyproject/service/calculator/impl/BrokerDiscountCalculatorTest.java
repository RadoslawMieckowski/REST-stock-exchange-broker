package com.griddynamics.fancyproject.service.calculator.impl;

import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.model.Stock;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BrokerDiscountCalculatorTest {

    static BrokerDiscountCalculator calculator = new BrokerDiscountCalculator(Arrays.asList("AMZN:2,META:1,TSLA:3".split(",")));

    @Test
    void calculateAssignsProperDiscountTest() {

        Stock stock1 = new Stock();
        stock1.setId(1);
        stock1.setName("Amazon");
        stock1.setQuantity(100);
        stock1.setPrice(BigDecimal.valueOf(100.00));
        stock1.setTicker("AMZN");

        Order order1 = new Order();
        order1.setId(1);
        order1.setQuantity(11);
        order1.setType(Order.OrderType.BUY);
        order1.setStock(stock1);

        List<Order> orders = List.of(order1);

        calculator.calculate(orders);

        assertEquals(22d, orders.get(0).getDiscount().doubleValue());
    }

}