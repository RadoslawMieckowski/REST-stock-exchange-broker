package com.griddynamics.fancyproject.service;

import com.griddynamics.fancyproject.exceptions.NotEnoughStockException;
import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.model.User;
import com.griddynamics.fancyproject.repository.OrderRepository;
import com.griddynamics.fancyproject.repository.StockRepository;
import com.griddynamics.fancyproject.repository.UserRepository;
import com.griddynamics.fancyproject.service.calculator.impl.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.context.ApplicationContext;


import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class OrderServiceTest {

    OrderService orderService;
    OrderRepository orderRepository;
    StockRepository stockRepository;
    UserRepository userRepository;
    ApplicationContext applicationContext;

    @BeforeEach
    void setUp() {
        userRepository = Mockito.mock(UserRepository.class);
        stockRepository = Mockito.mock(StockRepository.class);
        orderRepository = Mockito.mock(OrderRepository.class);
        applicationContext = Mockito.mock(ApplicationContext.class);
        Mockito.when(applicationContext.getBean(BrokerCommissionCalculator.class)).thenReturn(new BrokerCommissionCalculator(BigDecimal.valueOf(1), BigDecimal.valueOf(2)));
        Mockito.when(applicationContext.getBean(BrokerDiscountCalculator.class)).thenReturn(new BrokerDiscountCalculator(Arrays.asList("AMZN:2,META:1,TSLA:3".split(","))));
        Mockito.when(applicationContext.getBean(TaxCalculator.class)).thenReturn(new TaxCalculator(17));
        Mockito.when(applicationContext.getBean(FreeStockCalculator.class)).thenReturn(new FreeStockCalculator(BigDecimal.valueOf(100)));
        Mockito.when(applicationContext.getBean(FinalOrderValueCalculator.class)).thenReturn(new FinalOrderValueCalculator());
        orderService = new OrderService(orderRepository, stockRepository, userRepository, applicationContext);
    }

    @Test
    void makeOrderTest() {
        User user1 = new User();
        user1.setId(1);
        user1.setName("User1");
        user1.setType(User.UserType.PRO);

        Stock stock1 = new Stock();
        stock1.setId(1);
        stock1.setName("Stock1");
        stock1.setQuantity(10);
        stock1.setPrice(BigDecimal.valueOf(3.70));
        stock1.setTicker("CDR");

        Order order1 = new Order();
        order1.setId(1);
        order1.setStock(stock1);
        order1.setUser(user1);
        order1.setType(Order.OrderType.BUY);
        order1.setQuantity(10);

        Mockito.when(userRepository.findById(1L)).thenReturn(Optional.of(user1));
        Mockito.when(stockRepository.findByTicker("CDR")).thenReturn(Optional.of(stock1));
        Mockito.when(orderRepository.save(Mockito.any())).thenReturn(null);

        stockRepository.save(stock1);
        userRepository.save(user1);

        orderService.makeOrder(List.of(order1));

        assertEquals(BigDecimal.valueOf(37.185), order1.getTotalPrice());

    }

    @Test
    void makeOrderThrowsNotEnoughStockException() {
        User user1 = new User();
        user1.setId(1);
        user1.setName("User1");
        user1.setType(User.UserType.PRO);

        Stock stock1 = new Stock();
        stock1.setId(1);
        stock1.setName("Stock1");
        stock1.setQuantity(10);
        stock1.setPrice(BigDecimal.valueOf(3.70));
        stock1.setTicker("CDR");

        Order order1 = new Order();
        order1.setId(1);
        order1.setStock(stock1);
        order1.setUser(user1);
        order1.setType(Order.OrderType.BUY);
        order1.setQuantity(100);

        Mockito.when(userRepository.findById(1L)).thenReturn(Optional.of(user1));
        Mockito.when(stockRepository.findByTicker("CDR")).thenReturn(Optional.of(stock1));
        Mockito.when(orderRepository.save(Mockito.any())).thenReturn(null);

        stockRepository.save(stock1);
        userRepository.save(user1);

        assertThrows(NotEnoughStockException.class, () -> orderService.makeOrder(List.of(order1)));
    }
}