package com.griddynamics.fancyproject.service;

import com.griddynamics.fancyproject.exceptions.NoSuchTickerException;
import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.repository.StockRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class StockServiceTest {

    StockService stockService;
    StockRepository stockRepository;

    @BeforeEach
    void setUp() {
        stockRepository = Mockito.mock(StockRepository.class);
        stockService = new StockService(stockRepository);
    }

    @Test
    void shouldReturnAllStocks() {
        List<Stock> stocks = new LinkedList<>();
        var stock1 = new Stock();
        stock1.setId(1L);
        stock1.setName("AMAZON");
        stock1.setTicker("AMZ");
        stock1.setQuantity(2L);
        stock1.setPrice(BigDecimal.valueOf(19.95));

        var stock2 = new Stock();
        stock2.setId(2L);
        stock2.setName("TESLA");
        stock2.setTicker("TSLA");
        stock2.setQuantity(5L);
        stock2.setPrice(BigDecimal.valueOf(21.37));

        stocks.add(stock1);
        stocks.add(stock2);

        Mockito.when(stockRepository.findAll()).thenReturn(stocks);
        var result = stockService.getAllStocks();

        assertEquals(2, result.size());
        assertEquals("AMAZON", result.get(0).getName());
        assertEquals("TESLA", result.get(1).getName());
    }

    @Test
    void shouldReturnStockByTicker() {
        var stock1 = new Stock();

        stock1.setId(1L);
        stock1.setName("AMAZON");
        stock1.setTicker("AMZ");
        stock1.setQuantity(2L);
        stock1.setPrice(BigDecimal.valueOf(19.95));

        Mockito.when(stockRepository.findByTicker(stock1.getTicker())).thenReturn(Optional.of(stock1));

        String ticker1 = stock1.getTicker();
        var result = stockService.getStockByTicker(ticker1);
        assertEquals(BigDecimal.valueOf(19.95), result.getPrice());

        String ticker2 = "TSLA";
        assertThrows(NoSuchTickerException.class, () -> stockService.getStockByTicker(ticker2));
    }
}