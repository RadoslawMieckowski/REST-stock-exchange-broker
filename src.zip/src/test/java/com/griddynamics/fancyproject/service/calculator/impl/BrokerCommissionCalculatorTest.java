package com.griddynamics.fancyproject.service.calculator.impl;

import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.model.User;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
class BrokerCommissionCalculatorTest {
    BrokerCommissionCalculator brokerCommissionCalculator = new BrokerCommissionCalculator(BigDecimal.valueOf(1), BigDecimal.valueOf(2));

    @Test
    void calculateTest() {
        List<Order> orders = new LinkedList<>();
        Stock stock1 = Stock.builder().id(1)
                .name("CD Projekt")
                .ticker("CDR")
                .price(BigDecimal.valueOf(50.0))
        .build();
        Stock stock2 = Stock.builder().id(1)
                .name("GridDynamics")
                .ticker("GDYN")
                .price(BigDecimal.valueOf(60.0))
                .build();

        User user1 = User.builder()
                .id(1)
                .name("user1")
                .type(User.UserType.REGULAR)
                .build();
        User user2 = User.builder()
                .id(2)
                .name("user2")
                .type(User.UserType.PRO)
                .build();

        Order order1 = Order.builder()
                .id(1)
                .stock(stock1)
                .quantity(10)
                .user(user1)
                .type(Order.OrderType.BUY)
                .build();

        Order order2 = Order.builder()
                .id(2)
                .stock(stock2)
                .quantity(100)
                .user(user2)
                .type(Order.OrderType.SELL)
                .build();

        Order order3 = Order.builder()
                .id(3)
                .stock(stock1)
                .quantity(10)
                .user(user2)
                .type(Order.OrderType.BUY)
                .build();

        Order order4 = Order.builder()
                .id(4)
                .stock(stock2)
                .quantity(100)
                .user(user2)
                .type(Order.OrderType.SELL)
                .build();

        order1.setStock(stock1);
        order3.setStock(stock1);
        order2.setStock(stock2);
        order4.setStock(stock2);

        order1.setUser(user1);
        order2.setUser(user1);
        order3.setUser(user2);
        order4.setUser(user2);

        orders.add(order1);
        orders.add(order2);
        orders.add(order3);
        orders.add(order4);

        brokerCommissionCalculator.calculate(orders);

        assertThat(order1.getBrokerCommission().doubleValue()).isEqualTo(5.0);
        assertThat(order2.getBrokerCommission().doubleValue()).isEqualTo(120.0);
        assertThat(order3.getBrokerCommission().doubleValue()).isEqualTo(2.5);
        assertThat(order4.getBrokerCommission().doubleValue()).isEqualTo(60.0);
    }
}