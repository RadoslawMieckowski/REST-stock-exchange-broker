package com.griddynamics.fancyproject.controllers.mapper;

import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.model.User;
import com.griddynamics.fancyproject.model.dto.OrderDto;
import com.griddynamics.fancyproject.model.dto.StockDto;
import com.griddynamics.fancyproject.model.dto.UserDto;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class OrderMapperTest {

    OrderMapper mapper = new OrderMapperImpl();

    @Test
    public void toDtoShouldGenerateDto() {
        Stock stock = new Stock();
        stock.setId(1L);
        stock.setName("AMAZON");
        stock.setTicker("AMZ");
        stock.setQuantity(2L);
        stock.setPrice(BigDecimal.valueOf(19.95));

        User user = new User();
        user.setId(3L);
        user.setName("Jan");
        user.setType(User.UserType.REGULAR);

        Order order = Order.builder()
                .id(4L)
                .stock(stock)
                .user(user)
                .quantity(5)
                .type(Order.OrderType.SELL)
                .totalPrice(BigDecimal.valueOf(42))
                .brokerCommission(BigDecimal.valueOf(6))
                .build();

        OrderDto result = mapper.toDto(order);

        assertEquals(order.getId(), result.getId());
        assertEquals(order.getStock().getTicker(), result.getStock().getTicker());
        assertEquals(order.getUser().getId(), result.getUser().getId());
        assertEquals(order.getUser().getType().toString(), result.getUser().getType().getValue());
        assertEquals(order.getQuantity(), result.getQuantity());
        assertEquals(order.getType().toString(), result.getType().getValue());
        assertEquals(order.getTotalPrice(), result.getTotalPrice());
        assertEquals(order.getBrokerCommission(), result.getBrokerCommission());
    }

    @Test
    public void fromDtoToShouldGenerateModel() {

        UserDto userDto = new UserDto();
        userDto.setId(7L);
        userDto.setName("Sam");
        userDto.setType(UserDto.TypeEnum.PRO);

        StockDto stockDto = new StockDto();
        stockDto.setId(8L);
        stockDto.setName("TESLA");
        stockDto.setTicker("TSLA");
        stockDto.setQuantity(9L);
        stockDto.setPrice(BigDecimal.valueOf(19.95));

        OrderDto orderDto = OrderDto.builder()
                .id(1L)
                .stock(stockDto)
                .user(userDto)
                .quantity(9L)
                .type(OrderDto.TypeEnum.BUY)
                .totalPrice(BigDecimal.valueOf(42))
                .brokerCommission(BigDecimal.valueOf(10))
                .build();

        Order result = mapper.fromDto(orderDto);

        assertEquals(orderDto.getId(), result.getId());
        assertEquals(orderDto.getStock().getTicker(), result.getStock().getTicker());
        assertEquals(orderDto.getUser().getType().getValue(), result.getUser().getType().toString());
        assertEquals(orderDto.getQuantity(), result.getQuantity());
        assertEquals(orderDto.getType().getValue(), result.getType().toString());
        assertEquals(orderDto.getTotalPrice(), result.getTotalPrice());
        assertEquals(orderDto.getBrokerCommission(), result.getBrokerCommission());
    }
}