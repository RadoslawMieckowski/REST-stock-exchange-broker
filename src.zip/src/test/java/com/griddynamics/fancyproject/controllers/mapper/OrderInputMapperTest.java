package com.griddynamics.fancyproject.controllers.mapper;

import com.griddynamics.fancyproject.exceptions.NoSuchStockException;
import com.griddynamics.fancyproject.exceptions.NoSuchUserException;
import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.model.User;
import com.griddynamics.fancyproject.model.dto.OrderInputDto;
import com.griddynamics.fancyproject.repository.StockRepository;
import com.griddynamics.fancyproject.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OrderInputMapperTest {

    @Mock
    StockRepository stockRepository;
    @Mock
    UserRepository userRepository;

    @InjectMocks
    OrderInputMapper mapper = new OrderInputMapperImpl();

    @Test
    public void fromOrderInputDtoShouldMapToOrder() {

        Stock stock = new Stock();
        stock.setId(1L);
        stock.setName("AMAZON");
        stock.setTicker("AMZ");
        stock.setQuantity(2L);
        stock.setPrice(BigDecimal.valueOf(19.95));

        User user = new User();
        user.setId(1L);
        user.setName("Jan");
        user.setType(User.UserType.REGULAR);

        when(stockRepository.findByTicker(stock.getTicker())).thenReturn(Optional.of(stock));
        when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));

        OrderInputDto orderInputDto = OrderInputDto.builder()
                .userId(user.getId())
                .type(OrderInputDto.TypeEnum.BUY)
                .ticker(stock.getTicker())
                .quantity(stock.getQuantity())
                .build();

        Order result = mapper.fromOrderInput(orderInputDto);

        assertEquals(orderInputDto.getUserId(), result.getUser().getId());
        assertEquals(orderInputDto.getType().getValue(), result.getType().toString());
        assertEquals(orderInputDto.getTicker(), result.getStock().getTicker());
        assertEquals(orderInputDto.getQuantity(), result.getQuantity());

        assertDoesNotThrow(() -> mapper.getUserById(1));
        assertThrows(NoSuchUserException.class, () -> mapper.getUserById(5));
        assertDoesNotThrow(() -> mapper.getStockByTicker("AMZ"));
        assertThrows(NoSuchStockException.class, () -> mapper.getStockByTicker("META"));
    }
}