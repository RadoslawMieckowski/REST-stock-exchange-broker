package com.griddynamics.fancyproject.controllers;

import com.griddynamics.fancyproject.model.dto.StockDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.math.BigDecimal;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase
public class StocksControllerMethodsTest {
    @Autowired
    private WebApplicationContext webApplicationContext;
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private StocksController controller;

    @BeforeEach
    public void setup() throws Exception {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webApplicationContext).build();
    }

    @Test
    public void shouldPrintAllObjectsWhenPerformGetTest() throws Exception {
        List<StockDto> stocks = controller.getStocksDto();
        StockDto stock1 = StockDto.builder().ticker("CDR")
                .id((long) 1)
                .name("CD Projekt")
                .quantity((long) 100)
                .price(BigDecimal.valueOf(57.23))
                .build();
        stocks.add(stock1);
        StockDto stock2 = StockDto.builder().ticker("TSLA")
                .id((long) 2)
                .name("Tesla")
                .quantity((long) 10)
                .price(BigDecimal.valueOf(660.23))
                .build();
        stocks.add(stock2);

        this.mockMvc.perform(get("/stocks"))
                .andDo(print()).andExpect(status().isOk())
                .andExpect(
                        jsonPath("$.[0].id").value("1"))
                .andExpect(
                        jsonPath("$.[0].ticker").value("CDR"))
                .andExpect(
                        jsonPath("$.[0].name").value("CD Projekt"))
                .andExpect(
                        jsonPath("$.[0].quantity").value("100"))
                .andExpect(
                        jsonPath("$.[0].price").value("57.23"))
                .andExpect(
                        jsonPath("$.[1].id").value("2"))
                .andExpect(
                        jsonPath("$.[1].ticker").value("TSLA"))
                .andExpect(
                        jsonPath("$.[1].name").value("Tesla"))
                .andExpect(
                        jsonPath("$.[1].quantity").value("10"))
                .andExpect(
                        jsonPath("$.[1].price").value("660.23"));
    }

//    @Test
//    public void shouldPrintFirstObjectWhenPerformGetWithTickerEqualToCDRTest() throws Exception {
//        List<StockDto> stocks = controller.getStocksDto();
//        StockDto stock1 = StockDto.builder().ticker("CDR")
//                .id((long) 1)
//                .name("CD Projekt")
//                .quantity((long) 100)
//                .price(BigDecimal.valueOf(57.23))
//                .build();
//        stocks.add(stock1);
//        StockDto stock2 = StockDto.builder().ticker("TSLA")
//                .id((long) 2)
//                .name("Tesla")
//                .quantity((long) 10)
//                .price(BigDecimal.valueOf(660.23))
//                .build();
//        stocks.add(stock2);
//
//        this.mockMvc.perform(get("/stocks/CDR"))
//                .andDo(print()).andExpect(status().isOk())
//                .andExpect(
//                        jsonPath("$.id").value("1"))
//                .andExpect(
//                        jsonPath("$.ticker").value("CDR"))
//                .andExpect(
//                        jsonPath("$.name").value("CD Projekt"))
//                .andExpect(
//                        jsonPath("$.quantity").value("100"))
//                .andExpect(
//                        jsonPath("$.price").value("57.23"));
//    }

//    @Test
//    public void shouldPrintFirstObjectWhenPerformGetWithTickerEqualToTSLATest() throws Exception {
//        List<StockDto> stocks = controller.getStocksDto();
//        StockDto stock1 = StockDto.builder().ticker("CDR")
//                .id((long) 1)
//                .name("CD Projekt")
//                .quantity((long) 100)
//                .price(BigDecimal.valueOf(57.23))
//                .build();
//        stocks.add(stock1);
//        StockDto stock2 = StockDto.builder().ticker("TSLA")
//                .id((long) 2)
//                .name("Tesla")
//                .quantity((long) 10)
//                .price(BigDecimal.valueOf(660.23))
//                .build();
//        stocks.add(stock2);
//
//        this.mockMvc.perform(get("/stocks/TSLA"))
//                .andDo(print()).andExpect(status().isOk())
//                .andExpect(
//                        jsonPath("$.id").value("2"))
//                .andExpect(
//                        jsonPath("$.ticker").value("TSLA"))
//                .andExpect(
//                        jsonPath("$.name").value("Tesla"))
//                .andExpect(
//                        jsonPath("$.quantity").value("10"))
//                .andExpect(
//                        jsonPath("$.price").value("660.23"));
//    }
}
