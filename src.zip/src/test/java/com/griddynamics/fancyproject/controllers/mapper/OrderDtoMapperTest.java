package com.griddynamics.fancyproject.controllers.mapper;

import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.model.User;
import com.griddynamics.fancyproject.model.dto.OrderDto;
import com.griddynamics.fancyproject.model.dto.StockDto;
import com.griddynamics.fancyproject.model.dto.UserDto;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

import static org.junit.jupiter.api.Assertions.*;

class OrderDtoMapperTest {

    OrderDtoMapper orderDtoMapper = new OrderDtoMapperImpl();

    @Test
    void toDtoTest() {
        var stock = Stock.builder()
                .id(2)
                .name("Stock2")
                .ticker("GDYN")
                .price(BigDecimal.valueOf(2.12))
                .quantity(2)
                .build();

        var user = User.builder()
                .id(1)
                .name("User1")
                .type(User.UserType.PRO)
                .build();

        OffsetDateTime now = OffsetDateTime.now();
        String nowString = now.toString();

        var order = Order.builder()
                .user(user)
                .stock(stock)
                .id(4)
                .quantity(18)
                .type(Order.OrderType.BUY)
                .brokerCommission(BigDecimal.valueOf(0))
                .totalPrice(BigDecimal.valueOf(38.35))
                .orderDate(now)
                .build();

        var userDto = UserDto.builder()
                .id(1L)
                .name("User1")
                .type(UserDto.TypeEnum.PRO)
                .build();

        var stockDto = StockDto.builder()
                .id(2L)
                .name("Stock2")
                .ticker("GDYN")
                .price(BigDecimal.valueOf(2.12))
                .quantity(2L)
                .build();

        var orderDto = OrderDto.builder()
                .user(userDto)
                .stock(stockDto)
                .id(4L)
                .quantity(18L)
                .type(OrderDto.TypeEnum.BUY)
                .brokerCommission(BigDecimal.valueOf(0))
                .totalPrice(BigDecimal.valueOf(38.35))
                .date(nowString)
                .build();

        assertEquals(orderDto, orderDtoMapper.toDto(order));
    }
}