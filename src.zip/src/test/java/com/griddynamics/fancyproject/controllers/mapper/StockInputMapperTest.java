package com.griddynamics.fancyproject.controllers.mapper;

import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.model.dto.StockInputDto;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class StockInputMapperTest {

    StockInputMapper mapper = new StockInputMapperImpl();

    @Test
    public void toInputDtoShouldGenerateDto() {
        Stock stock = new Stock();
        stock.setId(1L);
        stock.setName("AMAZON");
        stock.setTicker("AMZ");
        stock.setQuantity(2L);
        stock.setPrice(BigDecimal.valueOf(19.95));

        StockInputDto result = mapper.toInputDto(stock);

        assertEquals(stock.getId(), result.getId());
        assertEquals(stock.getName(), result.getName());
        assertEquals(stock.getTicker(), result.getTicker());
        assertEquals(stock.getQuantity(), result.getQuantity());
        assertEquals(stock.getPrice(), result.getPrice());
    }

    @Test
    public void fromInputDtoShouldGenerateModel() {
        StockInputDto stockInputDto = new StockInputDto();
        stockInputDto.setId(3L);
        stockInputDto.setName("TESLA");
        stockInputDto.setTicker("TSLA");
        stockInputDto.setQuantity(4L);
        stockInputDto.setPrice(BigDecimal.valueOf(19.95));

        Stock result = mapper.fromInputDto(stockInputDto);

        assertEquals(stockInputDto.getId(), result.getId());
        assertEquals(stockInputDto.getName(), result.getName());
        assertEquals(stockInputDto.getTicker(), result.getTicker());
        assertEquals(stockInputDto.getQuantity(), result.getQuantity());
        assertEquals(stockInputDto.getPrice(), result.getPrice());
    }

}