package com.griddynamics.fancyproject.controllers.mapper;

import com.griddynamics.fancyproject.model.Order;
import com.griddynamics.fancyproject.model.User;
import com.griddynamics.fancyproject.model.dto.OrderDto;
import com.griddynamics.fancyproject.model.dto.UserDto;
import org.junit.jupiter.api.Test;

import java.util.LinkedList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class UserMapperTest {

    UserMapper mapper = new UserMapperImpl();

    @Test
    void toDtoShouldGenerateDto() {

        List<Order> orders = new LinkedList<>();

        User user = new User();
        user.setId(3L);
        user.setName("Jan");
        user.setType(User.UserType.REGULAR);
        user.setOrders(orders);

        UserDto result = mapper.toDto(user);

        assertEquals(user.getId(), result.getId());
        assertEquals(user.getName(), result.getName());
        assertEquals(user.getType().toString(), result.getType().toString());
    }

    @Test
    void fromDtoShouldGenerateModel() {
        List<OrderDto> orders = new LinkedList<>();

        UserDto userDto = new UserDto();
        userDto.setId(4L);
        userDto.setName("Alex");
        userDto.setType(UserDto.TypeEnum.PRO);

        User result = mapper.fromDto(userDto);

        assertEquals(userDto.getId(), result.getId());
        assertEquals(userDto.getName(), result.getName());
        assertEquals(userDto.getType().toString(), result.getType().toString());

    }

}