package com.griddynamics.fancyproject.controllers;

import com.griddynamics.fancyproject.controllers.mapper.UserInputMapperImpl;
import com.griddynamics.fancyproject.repository.UserRepository;
import com.griddynamics.fancyproject.service.OrderService;
import com.griddynamics.fancyproject.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase
@RunWith(MockitoJUnitRunner.class)
class UsersControllerTest {
    @Autowired
    private WebApplicationContext webApplicationContext;
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private UserService service;
    @Autowired
    private UserInputMapperImpl userInputMapper;
    @Mock
    private UserRepository userRepository;

    @Test
    void createUserWithMocksTest() throws Exception{
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webApplicationContext).build();
        userRepository = Mockito.mock(UserRepository.class);
        ReflectionTestUtils.setField(service, "userRepository", userRepository);

        this.mockMvc.perform(post("/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                     {
                                         "name": "User3",
                                         "type": "PRO",
                                         "email": "User3@wp.pl",
                                         "password": "top_secret3"
                                     }
                                """))
                .andExpect(status().isCreated());
    }
}