package com.griddynamics.fancyproject.controllers.mapper;

import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.model.dto.StockDto;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class StockMapperTest {

    StockMapper mapper = new StockMapperImpl();

    @Test
    public void toDtoShouldGenerateDto() {
        Stock stock = new Stock();
        stock.setId(1L);
        stock.setName("AMAZON");
        stock.setTicker("AMZ");
        stock.setQuantity(2L);
        stock.setPrice(BigDecimal.valueOf(19.95));

        StockDto result = mapper.toDto(stock);

        assertEquals(stock.getId(), result.getId());
        assertEquals(stock.getName(), result.getName());
        assertEquals(stock.getTicker(), result.getTicker());
        assertEquals(stock.getQuantity(), result.getQuantity());
        assertEquals(stock.getPrice(), result.getPrice());
    }

    @Test
    public void fromDtoShouldGenerateModel() {
        StockDto stockDto = new StockDto();
        stockDto.setId(3L);
        stockDto.setName("TESLA");
        stockDto.setTicker("TSLA");
        stockDto.setQuantity(4L);
        stockDto.setPrice(BigDecimal.valueOf(19.95));

        Stock result = mapper.fromDto(stockDto);

        assertEquals(stockDto.getId(), result.getId());
        assertEquals(stockDto.getName(), result.getName());
        assertEquals(stockDto.getTicker(), result.getTicker());
        assertEquals(stockDto.getQuantity(), result.getQuantity());
        assertEquals(stockDto.getPrice(), result.getPrice());
    }
}