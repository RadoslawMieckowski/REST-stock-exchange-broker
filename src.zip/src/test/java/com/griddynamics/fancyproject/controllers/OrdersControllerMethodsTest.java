package com.griddynamics.fancyproject.controllers;

import com.griddynamics.fancyproject.controllers.mapper.OrderInputMapperImpl;
import com.griddynamics.fancyproject.model.Stock;
import com.griddynamics.fancyproject.model.User;
import com.griddynamics.fancyproject.model.dto.OrderDto;
import com.griddynamics.fancyproject.model.dto.StockDto;
import com.griddynamics.fancyproject.model.dto.UserDto;
import com.griddynamics.fancyproject.repository.OrderRepository;
import com.griddynamics.fancyproject.repository.StockRepository;
import com.griddynamics.fancyproject.repository.UserRepository;
import com.griddynamics.fancyproject.service.OrderService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase
@RunWith(MockitoJUnitRunner.class)
public class OrdersControllerMethodsTest {
    @Autowired
    private WebApplicationContext webApplicationContext;
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private OrdersController controller;
    @Autowired
    private OrderService service;
    @Autowired
    private OrderInputMapperImpl orderInputMapper;
    @Mock
    private OrderRepository orderRepository;
    @Mock
    private StockRepository stockRepository;
    @Mock
    private UserRepository userRepository;

    @BeforeEach
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webApplicationContext).build();
    }

    @AfterEach
    public void clearOrders() {
        controller.getAllOrders().clear();
    }

    @Test
    public void shouldPrintFirstObjectWhenPerformGetWithIdEqualTo1Test() throws Exception {
        List<OrderDto> orders = controller.getAllOrders();
        StockDto stockDto = StockDto.builder()
                .ticker("CDR")
                .build();
        UserDto userDto = UserDto.builder()
                .name("user1")
                .build();

        OrderDto order1 = OrderDto.builder().id((long)1)
                .type(OrderDto.TypeEnum.BUY)
                .stock(stockDto)
                .user(userDto)
                .build();
        orders.add(order1);

        StockDto stockDto2 = StockDto.builder()
                .ticker("TSLA")
                .build();
        UserDto userDto2 = UserDto.builder()
                .name("user2")
                .build();

        OrderDto order2 = OrderDto.builder().id((long)2)
                .type(OrderDto.TypeEnum.SELL)
                .stock(stockDto2)
                .user(userDto2)
                .build();
        orders.add(order2);

      this.mockMvc.perform(get("/orders/1"))
                .andDo(print()).andExpect(status().isOk())
              .andExpect(
                      jsonPath("$.id").value("1"))
              .andExpect(
                      jsonPath("$.type").value("BUY"))
              .andExpect(
                      jsonPath("$.stock.ticker").value("CDR"))
              .andExpect(
                      jsonPath("$.user.name").value("user1"));
    }

    @Test
    public void shouldPrintFirstObjectWhenPerformGetWithIdEqualTo2Test() throws Exception {
        List<OrderDto> orders = controller.getAllOrders();
        StockDto stockDto = StockDto.builder()
                .ticker("CDR")
                .build();
        UserDto userDto = UserDto.builder()
                .name("user1")
                .build();

        OrderDto order1 = OrderDto.builder().id((long)1)
                .type(OrderDto.TypeEnum.BUY)
                .stock(stockDto)
                .user(userDto)
                .build();
        orders.add(order1);

        StockDto stockDto2 = StockDto.builder()
                .ticker("TSLA")
                .build();
        UserDto userDto2 = UserDto.builder()
                .name("user2")
                .build();

        OrderDto order2 = OrderDto.builder().id((long)2)
                .type(OrderDto.TypeEnum.SELL)
                .stock(stockDto2)
                .user(userDto2)
                .build();
        orders.add(order2);

        this.mockMvc.perform(get("/orders/2"))
                .andDo(print()).andExpect(status().isOk())
                .andExpect(
                        jsonPath("$.id").value("2"))
                .andExpect(
                        jsonPath("$.type").value("SELL"))
                .andExpect(
                        jsonPath("$.stock.ticker").value("TSLA"))
                .andExpect(
                        jsonPath("$.user.name").value("user2"));
    }

    @Test
    void givenOrdersURIWithPost_whenMockMVC_thenVerifyResponseTest() throws Exception{
        userRepository = Mockito.mock(UserRepository.class);
        stockRepository = Mockito.mock(StockRepository.class);
        orderRepository = Mockito.mock(OrderRepository.class);

        ReflectionTestUtils.setField(service, "orderRepository", orderRepository);
        ReflectionTestUtils.setField(service, "stockRepository", stockRepository);
        ReflectionTestUtils.setField(service, "userRepository", userRepository);

        ReflectionTestUtils.setField(orderInputMapper, "stockRepository", stockRepository);
        ReflectionTestUtils.setField(orderInputMapper, "userRepository", userRepository);

        User user1 = new User();
        user1.setId(1l);
        user1.setName("User1");
        user1.setType(User.UserType.PRO);

        Stock stock2 = new Stock();
        stock2.setName("Stock2");
        stock2.setPrice(BigDecimal.valueOf(2.12));
        stock2.setTicker("GDYN");
        stock2.setQuantity(20);

        Mockito.when(userRepository.findById(1l)).thenReturn(Optional.of(user1));
        Mockito.when(stockRepository.findByTicker("GDYN")).thenReturn(Optional.of(stock2));
        Mockito.when(orderRepository.save(Mockito.any())).thenReturn(null);


        this.mockMvc.perform(post("/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                    [
                                         {
                                             "userId": "1",
                                             "type": "BUY",
                                             "ticker": "GDYN",
                                             "quantity": "18"
                                         }
                                     ]
                                """))
                .andExpect(status().isCreated());
    }
}
