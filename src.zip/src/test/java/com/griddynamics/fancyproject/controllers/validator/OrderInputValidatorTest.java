package com.griddynamics.fancyproject.controllers.validator;

import com.griddynamics.fancyproject.exceptions.WrongDtoException;
import com.griddynamics.fancyproject.model.dto.OrderInputDto;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OrderInputValidatorTest {

    @Test
    void shouldThrowExceptionWhenInputIsNull() {
        OrderInputDto orderInputDto = null;

        Throwable exceptionThatWasThrown = assertThrows(WrongDtoException.class, () -> OrderInputValidator.validate(orderInputDto));
        assertEquals("Input is null", exceptionThatWasThrown.getMessage());
    }

    @Test
    void shouldThrowExceptionWhenInputValuesAreMissing() {
        OrderInputDto orderInputDto = new OrderInputDto();

        Throwable exception1 = assertThrows(WrongDtoException.class, () -> OrderInputValidator.validate(orderInputDto));
        assertEquals("One or more invalid input values: User id is missing, Type of transaction is missing, Ticker is missing, Specified quantity is missing",
                exception1.getMessage());

        orderInputDto.setUserId(1L);

        Throwable exception2 = assertThrows(WrongDtoException.class, () -> OrderInputValidator.validate(orderInputDto));
        assertEquals("One or more invalid input values: Type of transaction is missing, Ticker is missing, Specified quantity is missing",
                exception2.getMessage());

        orderInputDto.setType(OrderInputDto.TypeEnum.BUY);

        Throwable exception3 = assertThrows(WrongDtoException.class, () -> OrderInputValidator.validate(orderInputDto));
        assertEquals("One or more invalid input values: Ticker is missing, Specified quantity is missing",
                exception3.getMessage());

        orderInputDto.setTicker("AMZ");

        Throwable exception4 = assertThrows(WrongDtoException.class, () -> OrderInputValidator.validate(orderInputDto));
        assertEquals("One or more invalid input values: Specified quantity is missing",
                exception4.getMessage());

        orderInputDto.setQuantity(2L);

        assertDoesNotThrow(() -> OrderInputValidator.validate(orderInputDto));
    }

    @Test
    void tickerValidation() {

        OrderInputDto orderInput = new OrderInputDto();
        orderInput.setUserId(1L);
        orderInput.setType(OrderInputDto.TypeEnum.BUY);
        orderInput.setQuantity(2L);

        orderInput.setTicker("AMZ");
        assertEquals(0, OrderInputValidator.validate(orderInput).size());
        assertDoesNotThrow(() -> OrderInputValidator.validate(orderInput));

        orderInput.setTicker("AMAZON");
        assertThrows(WrongDtoException.class, () -> OrderInputValidator.validate(orderInput));

        orderInput.setTicker("amazon");
        assertThrows(WrongDtoException.class, () -> OrderInputValidator.validate(orderInput));

        orderInput.setTicker("AMZ1");
        assertThrows(WrongDtoException.class, () -> OrderInputValidator.validate(orderInput));

        orderInput.setTicker("1234");
        assertThrows(WrongDtoException.class, () -> OrderInputValidator.validate(orderInput));

        orderInput.setTicker(null);
        assertThrows(WrongDtoException.class, () -> OrderInputValidator.validate(orderInput));
    }

    @Test
    void quantityValidation() {
        OrderInputDto orderInput = new OrderInputDto();
        orderInput.setUserId(1L);
        orderInput.setType(OrderInputDto.TypeEnum.BUY);
        orderInput.setTicker("AMZ");

        orderInput.setQuantity(0L);
        assertEquals(0, OrderInputValidator.validate(orderInput).size());

        orderInput.setQuantity(1L);
        assertEquals(0, OrderInputValidator.validate(orderInput).size());

        orderInput.setQuantity(-5L);
        assertThrows(WrongDtoException.class, () -> OrderInputValidator.validate(orderInput));
    }
}