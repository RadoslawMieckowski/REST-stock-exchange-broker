//package com.griddynamics.fancyproject.controllers;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import static org.assertj.core.api.Assertions.*;
//
//@SpringBootTest
//@AutoConfigureTestDatabase
//class OrdersControllerTest {
//    @Autowired
//    private OrdersController controller;
//
//    @Test
//    public void contextLoadsWithNotNullController() throws Exception {
//        assertThat(controller).isNotNull();
//    }
//
//}